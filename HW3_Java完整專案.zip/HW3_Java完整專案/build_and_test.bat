@echo off
chcp 65001 >nul
if not exist build mkdir build
if exist sources.txt del sources.txt
for /r src %%f in (*.java) do @echo "%%f">>sources.txt
javac -encoding UTF-8 -d build @sources.txt
if errorlevel 1 (echo 編譯失敗& pause& exit /b 1)
python verify_all.py
pause
