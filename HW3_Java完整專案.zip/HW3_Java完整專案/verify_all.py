from pathlib import Path
import json, subprocess, os, sys
root=Path(__file__).resolve().parent
recs=json.loads((root/'metadata.json').read_text(encoding='utf-8'))
passed=0
for rec in recs:
    cmd=['java','-Dfile.encoding=UTF-8','-cp','build',rec['java_class']]+rec.get('args',[])
    try:
        result=subprocess.run(cmd,cwd=root,input=rec.get('stdin',''),encoding='utf-8',capture_output=True,timeout=12)
    except Exception as e:
        print('[FAIL]',rec['name'],str(e)); continue
    ok=(result.returncode==0) or (rec.get('expected_error') and 'ArrayIndexOutOfBoundsException' in result.stderr)
    passed+=int(ok)
    print(('OK' if ok else 'FAIL')+' '+rec['name']+'  '+rec['title'])
print('總計：',passed,'/',len(recs))
sys.exit(0 if passed==len(recs) else 1)
