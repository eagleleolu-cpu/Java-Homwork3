public class CH4_P32 { // 宣告本範例的類別，定義物件的資料與行為
    static abstract class Vehicle { abstract void show(); } // 完成此處的 Java 程式結構
    static class Car extends Vehicle { // 運用繼承或介面實作重複使用程式設計
        @Override // 標示此方法是覆寫父類別或介面的方法
        void show() { System.out.println("汽車"); } // 定義不需要回傳結果的物件方法
    } // 結束目前的程式區塊
    static class Plane extends Vehicle { // 運用繼承或介面實作重複使用程式設計
        @Override // 標示此方法是覆寫父類別或介面的方法
        void show() { System.out.println("飛機"); } // 定義不需要回傳結果的物件方法
    } // 結束目前的程式區塊
    public static void main(String[] args) { // Java 主程式的執行入口
        Vehicle[] fleet = {new Car(), new Plane()}; // 使用 new 建立物件並完成初始設定
        for (Vehicle v : fleet) { // 使用迴圈反覆處理一組資料
            if (v instanceof Car) { System.out.println("這是一台 Car"); } // 依照條件判斷是否執行下面的程式
            else { System.out.println("這不是 Car"); } // 在主控台顯示執行結果或提示文字
        } // 結束目前的程式區塊
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
