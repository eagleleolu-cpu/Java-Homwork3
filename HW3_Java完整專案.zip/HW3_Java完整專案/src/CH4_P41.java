public class CH4_P41 { // 宣告本範例的類別，定義物件的資料與行為
    interface Vehicle { void show(); } // 宣告介面或抽象類別，規範子類別必須完成的功能
    interface Maintenance { void service(); } // 宣告介面或抽象類別，規範子類別必須完成的功能
    static class Car implements Vehicle, Maintenance { // 運用繼承或介面實作重複使用程式設計
        @Override // 標示此方法是覆寫父類別或介面的方法
        public void show() { System.out.println("汽車資訊"); } // 定義不需要回傳結果的物件方法
        @Override // 標示此方法是覆寫父類別或介面的方法
        public void service() { System.out.println("汽車保養完成"); } // 定義不需要回傳結果的物件方法
    } // 結束目前的程式區塊
    public static void main(String[] args) { // Java 主程式的執行入口
        Car car = new Car(); // 使用 new 建立物件並完成初始設定
        car.show(); // 執行此行的指定運算或物件操作
        car.service(); // 執行此行的指定運算或物件操作
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
