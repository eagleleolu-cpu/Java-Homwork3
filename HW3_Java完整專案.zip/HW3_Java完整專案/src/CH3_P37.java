import java.util.Locale; // 匯入範例需要的 Java 標準函式庫
public class CH3_P37 { // 宣告本範例的類別，定義物件的資料與行為
    public static void main(String[] args) { // Java 主程式的執行入口
        String text = "Hello Java"; // 設定變數的數值或取得方法的處理結果
        String upper = text.toUpperCase(Locale.ROOT); // 設定變數的數值或取得方法的處理結果
        String lower = text.toLowerCase(Locale.ROOT); // 設定變數的數值或取得方法的處理結果
        System.out.println("原文：" + text); // 在主控台顯示執行結果或提示文字
        System.out.println("大寫：" + upper); // 在主控台顯示執行結果或提示文字
        System.out.println("小寫：" + lower); // 在主控台顯示執行結果或提示文字
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
