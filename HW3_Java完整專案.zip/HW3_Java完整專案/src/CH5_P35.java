import java.io.BufferedWriter; // 匯入範例需要的 Java 標準函式庫
import java.io.IOException; // 匯入範例需要的 Java 標準函式庫
import java.nio.charset.StandardCharsets; // 匯入範例需要的 Java 標準函式庫
import java.nio.file.Files; // 匯入範例需要的 Java 標準函式庫
import java.nio.file.Path; // 匯入範例需要的 Java 標準函式庫
import java.nio.file.Paths; // 匯入範例需要的 Java 標準函式庫
public class CH5_P35 { // 宣告本範例的類別，定義物件的資料與行為
    public static void main(String[] args) throws IOException { // Java 主程式的執行入口
        Path folder = Paths.get("data"); // 設定變數的數值或取得方法的處理結果
        Files.createDirectories(folder); // 執行此行的指定運算或物件操作
        Path file = folder.resolve("ch5_p35.txt"); // 設定變數的數值或取得方法的處理結果
        try (BufferedWriter writer = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) { // 嘗試執行可能發生例外的操作
            writer.write("Hello!"); writer.newLine(); // 將文字內容寫入輸出串流
            writer.write("Goodbye!"); writer.newLine(); // 將文字內容寫入輸出串流
        } // 結束目前的程式區塊
        System.out.println("已寫入：" + file.toAbsolutePath()); // 在主控台顯示執行結果或提示文字
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
