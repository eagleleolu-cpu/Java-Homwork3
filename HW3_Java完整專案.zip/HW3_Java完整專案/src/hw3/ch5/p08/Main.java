package hw3.ch5.p08; // 指定類別所屬的套件，避免名稱衝突
public class Main { // 宣告本範例的類別，定義物件的資料與行為
    public static void main(String[] args) { new Car().show(); } // Java 主程式的執行入口
} // 結束目前的程式區塊
