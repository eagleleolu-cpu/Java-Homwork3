package hw3.ch5.p08; // 指定類別所屬的套件，避免名稱衝突
public class Car { // 宣告本範例的類別，定義物件的資料與行為
    public void show() { System.out.println("同一套件中的 Car"); } // 定義不需要回傳結果的物件方法
} // 結束目前的程式區塊
