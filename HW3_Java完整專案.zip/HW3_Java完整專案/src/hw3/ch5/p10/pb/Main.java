package hw3.ch5.p10.pb; // 指定類別所屬的套件，避免名稱衝突
public class Main { // 宣告本範例的類別，定義物件的資料與行為
    public static void main(String[] args) { // Java 主程式的執行入口
        hw3.ch5.p10.pc.Car car = new hw3.ch5.p10.pc.Car(); // 使用 new 建立物件並完成初始設定
        car.show(); // 執行此行的指定運算或物件操作
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
