public class CH5_P47 { // 宣告本範例的類別，定義物件的資料與行為
    public static void main(String[] args) { // Java 主程式的執行入口
        for (int i = 1; i <= 3; i++) { // 使用迴圈反覆處理一組資料
            System.out.println("主執行緒步驟 " + i); // 在主控台顯示執行結果或提示文字
            try { Thread.sleep(100); } // 嘗試執行可能發生例外的操作
            catch (InterruptedException e) { Thread.currentThread().interrupt(); break; } // 處理執行時發生的例外情況
        } // 結束目前的程式區塊
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
