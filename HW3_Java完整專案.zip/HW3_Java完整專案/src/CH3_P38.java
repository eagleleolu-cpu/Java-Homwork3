public class CH3_P38 { // 宣告本範例的類別，定義物件的資料與行為
    public static void main(String[] args) { // Java 主程式的執行入口
        String text = "Java programming"; // 設定變數的數值或取得方法的處理結果
        char target = 'a'; // 設定變數的數值或取得方法的處理結果
        int index = text.indexOf(target); // 設定變數的數值或取得方法的處理結果
        if (index >= 0) { // 依照條件判斷是否執行下面的程式
            System.out.println("找到字元，索引：" + index); // 在主控台顯示執行結果或提示文字
        } else { // 在前面條件不成立時執行其他路徑
            System.out.println("找不到指定字元"); // 在主控台顯示執行結果或提示文字
        } // 結束目前的程式區塊
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
