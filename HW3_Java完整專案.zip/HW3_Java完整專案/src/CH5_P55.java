public class CH5_P55 { // 宣告本範例的類別，定義物件的資料與行為
    static class Account { // 開始此方法、控制流程或類別區塊
        private int balance = 0; // 宣告成員欄位並設定適當的存取範圍
        synchronized void add() { balance++; } // 限制同時存取共用資料，避免競爭條件
        synchronized int getBalance() { return balance; } // 限制同時存取共用資料，避免競爭條件
    } // 結束目前的程式區塊
    public static void main(String[] args) throws InterruptedException { // Java 主程式的執行入口
        Account account = new Account(); // 使用 new 建立物件並完成初始設定
        Runnable task = () -> { for (int i = 0; i < 3000; i++) { account.add(); } }; // 設定變數的數值或取得方法的處理結果
        Thread first = new Thread(task); // 使用 new 建立物件並完成初始設定
        Thread second = new Thread(task); // 使用 new 建立物件並完成初始設定
        first.start(); second.start(); first.join(); second.join(); // 啟動新的執行緒並呼叫其 run 方法
        System.out.println("同步化餘額：" + account.getBalance()); // 在主控台顯示執行結果或提示文字
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
