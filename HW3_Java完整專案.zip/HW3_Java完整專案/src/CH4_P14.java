public class CH4_P14 { // 宣告本範例的類別，定義物件的資料與行為
    static class Car { void show() { System.out.println("一般汽車"); } } // 在主控台顯示執行結果或提示文字
    static class RacingCar extends Car { // 運用繼承或介面實作重複使用程式設計
        @Override // 標示此方法是覆寫父類別或介面的方法
        void show() { System.out.println("賽車的 show() 被呼叫"); } // 定義不需要回傳結果的物件方法
        void race() { System.out.println("開始比賽"); } // 定義不需要回傳結果的物件方法
    } // 結束目前的程式區塊
    public static void main(String[] args) { // Java 主程式的執行入口
        Car car = new RacingCar(); // 使用 new 建立物件並完成初始設定
        car.show(); // 執行此行的指定運算或物件操作
        if (car instanceof RacingCar) { ((RacingCar) car).race(); } // 依照條件判斷是否執行下面的程式
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
