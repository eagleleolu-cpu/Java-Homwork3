public class CH3_P45 { // 宣告本範例的類別，定義物件的資料與行為
    static class Car { int number; } // 完成此處的 Java 程式結構
    public static void main(String[] args) { // Java 主程式的執行入口
        Car car1 = new Car(); // 使用 new 建立物件並完成初始設定
        car1.number = 1234; // 設定變數的數值或取得方法的處理結果
        Car car2 = car1; // 設定變數的數值或取得方法的處理結果
        car1.number = 5678; // 設定變數的數值或取得方法的處理結果
        System.out.println("car1：" + car1.number); // 在主控台顯示執行結果或提示文字
        System.out.println("car2：" + car2.number); // 在主控台顯示執行結果或提示文字
        System.out.println("同一物件：" + (car1 == car2)); // 在主控台顯示執行結果或提示文字
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
