public class CH3_P26 { // 宣告本範例的類別，定義物件的資料與行為
    static class Car { // 開始此方法、控制流程或類別區塊
        private int number; // 宣告成員欄位並設定適當的存取範圍
        private double gas; // 宣告成員欄位並設定適當的存取範圍
        Car() { number = 0; gas = 0.0; System.out.println("已建立車輛"); } // 在主控台顯示執行結果或提示文字
        void show() { System.out.println(number + " / " + gas); } // 定義不需要回傳結果的物件方法
    } // 結束目前的程式區塊
    public static void main(String[] args) { new Car().show(); } // Java 主程式的執行入口
} // 結束目前的程式區塊
