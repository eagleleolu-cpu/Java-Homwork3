public class CH5_P19 { // 宣告本範例的類別，定義物件的資料與行為
    public static void main(String[] args) { // Java 主程式的執行入口
        int[] scores = new int[5]; // 使用 new 建立物件並完成初始設定
        System.out.println("準備存取索引 10"); // 在主控台顯示執行結果或提示文字
        scores[10] = 80; // 設定變數的數值或取得方法的處理結果
        System.out.println("此行不會執行：" + scores[10]); // 在主控台顯示執行結果或提示文字
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
