public class CH3_P31 { // 宣告本範例的類別，定義物件的資料與行為
    static class Car { // 開始此方法、控制流程或類別區塊
        private static int count = 0; // 宣告成員欄位並設定適當的存取範圍
        Car() { count++; } // 完成此處的 Java 程式結構
        static int getCount() { return count; } // 定義具有回傳值的物件方法
    } // 結束目前的程式區塊
    public static void main(String[] args) { // Java 主程式的執行入口
        new Car(); // 使用 new 建立物件並完成初始設定
        new Car(); // 使用 new 建立物件並完成初始設定
        System.out.println("已建立車輛數：" + Car.getCount()); // 在主控台顯示執行結果或提示文字
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
