public class CH3_P09 { // 宣告本範例的類別，定義物件的資料與行為
    static class Car { // 開始此方法、控制流程或類別區塊
        int number; // 執行此行的指定運算或物件操作
        double gas; // 執行此行的指定運算或物件操作
        void show() { // 定義不需要回傳結果的物件方法
            System.out.println("車號：" + this.number); // 在主控台顯示執行結果或提示文字
            System.out.println("汽油量：" + gas); // 在主控台顯示執行結果或提示文字
        } // 結束目前的程式區塊
    } // 結束目前的程式區塊
    public static void main(String[] args) { // Java 主程式的執行入口
        Car car = new Car(); // 使用 new 建立物件並完成初始設定
        car.number = 1234; car.gas = 20.5; // 設定變數的數值或取得方法的處理結果
        car.show(); // 執行此行的指定運算或物件操作
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
