public class CH4_P17 { // 宣告本範例的類別，定義物件的資料與行為
    static class Car { void show() { System.out.println("一般汽車"); } } // 在主控台顯示執行結果或提示文字
    static class RacingCar extends Car { // 運用繼承或介面實作重複使用程式設計
        @Override // 標示此方法是覆寫父類別或介面的方法
        void show() { System.out.println("賽車"); } // 定義不需要回傳結果的物件方法
    } // 結束目前的程式區塊
    public static void main(String[] args) { // Java 主程式的執行入口
        Car[] vehicles = {new Car(), new RacingCar()}; // 使用 new 建立物件並完成初始設定
        for (Car car : vehicles) { car.show(); } // 使用迴圈反覆處理一組資料
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
