public class CH5_P46 { // 宣告本範例的類別，定義物件的資料與行為
    static class Worker extends Thread { // 運用繼承或介面實作重複使用程式設計
        @Override // 標示此方法是覆寫父類別或介面的方法
        public void run() { // 定義不需要回傳結果的物件方法
            for (int i = 1; i <= 3; i++) { // 使用迴圈反覆處理一組資料
                System.out.println("子執行緒步驟 " + i); // 在主控台顯示執行結果或提示文字
                try { Thread.sleep(100); } // 嘗試執行可能發生例外的操作
                catch (InterruptedException e) { Thread.currentThread().interrupt(); return; } // 處理執行時發生的例外情況
            } // 結束目前的程式區塊
        } // 結束目前的程式區塊
    } // 結束目前的程式區塊
    public static void main(String[] args) throws InterruptedException { // Java 主程式的執行入口
        Worker worker = new Worker(); worker.start(); worker.join(); // 啟動新的執行緒並呼叫其 run 方法
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
