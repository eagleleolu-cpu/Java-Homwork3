public class CH4_P29 { // 宣告本範例的類別，定義物件的資料與行為
    static abstract class Vehicle { // 開始此方法、控制流程或類別區塊
        private int speed; // 宣告成員欄位並設定適當的存取範圍
        void setSpeed(int s) { speed = s; } // 定義不需要回傳結果的物件方法
        int getSpeed() { return speed; } // 定義具有回傳值的物件方法
        abstract void show(); // 執行此行的指定運算或物件操作
    } // 結束目前的程式區塊
    static class Car extends Vehicle { // 運用繼承或介面實作重複使用程式設計
        @Override // 標示此方法是覆寫父類別或介面的方法
        void show() { System.out.println("汽車速度：" + getSpeed()); } // 定義不需要回傳結果的物件方法
    } // 結束目前的程式區塊
    static class Plane extends Vehicle { // 運用繼承或介面實作重複使用程式設計
        @Override // 標示此方法是覆寫父類別或介面的方法
        void show() { System.out.println("飛機速度：" + getSpeed()); } // 定義不需要回傳結果的物件方法
    } // 結束目前的程式區塊
    public static void main(String[] args) { // Java 主程式的執行入口
        Vehicle[] fleet = {new Car(), new Plane()}; // 使用 new 建立物件並完成初始設定
        fleet[0].setSpeed(60); fleet[1].setSpeed(500); // 執行此行的指定運算或物件操作
        for (Vehicle v : fleet) { v.show(); } // 使用迴圈反覆處理一組資料
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
