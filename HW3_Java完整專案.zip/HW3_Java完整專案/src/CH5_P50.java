public class CH5_P50 { // 宣告本範例的類別，定義物件的資料與行為
    static class Task implements Runnable { // 運用繼承或介面實作重複使用程式設計
        @Override // 標示此方法是覆寫父類別或介面的方法
        public void run() { System.out.println("Runnable 任務進行中"); } // 定義不需要回傳結果的物件方法
    } // 結束目前的程式區塊
    public static void main(String[] args) throws InterruptedException { // Java 主程式的執行入口
        Thread worker = new Thread(new Task()); // 使用 new 建立物件並完成初始設定
        worker.start(); // 啟動新的執行緒並呼叫其 run 方法
        worker.join(); // 等待指定執行緒結束，再繼續下一步
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
