public class CH3_P16 { // 宣告本範例的類別，定義物件的資料與行為
    static class Car { // 開始此方法、控制流程或類別區塊
        private int number = 1234; // 宣告成員欄位並設定適當的存取範圍
        int getNum() { return number; } // 定義具有回傳值的物件方法
    } // 結束目前的程式區塊
    public static void main(String[] args) { // Java 主程式的執行入口
        Car car = new Car(); // 使用 new 建立物件並完成初始設定
        int result = car.getNum(); // 設定變數的數值或取得方法的處理結果
        System.out.println("取得車號：" + result); // 在主控台顯示執行結果或提示文字
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
