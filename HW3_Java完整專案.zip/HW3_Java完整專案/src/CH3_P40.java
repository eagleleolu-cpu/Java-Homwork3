public class CH3_P40 { // 宣告本範例的類別，定義物件的資料與行為
    public static void main(String[] args) { // Java 主程式的執行入口
        String first = "Hello"; // 設定變數的數值或取得方法的處理結果
        String second = " Java"; // 設定變數的數值或取得方法的處理結果
        StringBuffer buffer = new StringBuffer(first); // 使用 new 建立物件並完成初始設定
        buffer.append(second); // 執行此行的指定運算或物件操作
        System.out.println("串接結果：" + buffer.toString()); // 在主控台顯示執行結果或提示文字
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
