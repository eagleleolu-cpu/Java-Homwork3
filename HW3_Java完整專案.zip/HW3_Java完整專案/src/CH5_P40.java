import java.io.IOException; // 匯入範例需要的 Java 標準函式庫
import java.nio.charset.StandardCharsets; // 匯入範例需要的 Java 標準函式庫
import java.nio.file.Files; // 匯入範例需要的 Java 標準函式庫
import java.nio.file.Path; // 匯入範例需要的 Java 標準函式庫
import java.nio.file.Paths; // 匯入範例需要的 Java 標準函式庫
public class CH5_P40 { // 宣告本範例的類別，定義物件的資料與行為
    public static void main(String[] args) throws IOException { // Java 主程式的執行入口
        if (args.length == 0) { System.out.println("請帶入檔名，例如 data/ch5_p35.txt"); return; } // 依照條件判斷是否執行下面的程式
        Path file = Paths.get(args[0]); // 設定變數的數值或取得方法的處理結果
        if (!Files.exists(file)) { System.out.println("檔案不存在：" + file); return; } // 依照條件判斷是否執行下面的程式
        for (String line : Files.readAllLines(file, StandardCharsets.UTF_8)) { // 使用迴圈反覆處理一組資料
            System.out.println(line); // 在主控台顯示執行結果或提示文字
        } // 結束目前的程式區塊
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
