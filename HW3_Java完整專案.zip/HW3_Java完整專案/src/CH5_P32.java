public class CH5_P32 { // 宣告本範例的類別，定義物件的資料與行為
    static class CarException extends Exception { // 運用繼承或介面實作重複使用程式設計
        CarException(String text) { super(text); } // 完成此處的 Java 程式結構
    } // 結束目前的程式區塊
    static void setGas(double gas) throws CarException { // 定義不需要回傳結果的物件方法
        if (gas < 0) { throw new CarException("不能設定負油量"); } // 依照條件判斷是否執行下面的程式
        System.out.println("設定成功：" + gas); // 在主控台顯示執行結果或提示文字
    } // 結束目前的程式區塊
    static void process() throws CarException { setGas(-10.0); } // 定義不需要回傳結果的物件方法
    public static void main(String[] args) { // Java 主程式的執行入口
        try { process(); } // 嘗試執行可能發生例外的操作
        catch (CarException e) { System.out.println("主程式收到：" + e.getMessage()); } // 處理執行時發生的例外情況
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
