public class CH3_P36 { // 宣告本範例的類別，定義物件的資料與行為
    public static void main(String[] args) { // Java 主程式的執行入口
        String text = "Hello"; // 設定變數的數值或取得方法的處理結果
        char first = text.charAt(0); // 設定變數的數值或取得方法的處理結果
        char second = text.charAt(1); // 設定變數的數值或取得方法的處理結果
        int length = text.length(); // 設定變數的數值或取得方法的處理結果
        System.out.println("第一個字：" + first); // 在主控台顯示執行結果或提示文字
        System.out.println("第二個字：" + second); // 在主控台顯示執行結果或提示文字
        System.out.println("長度：" + length); // 在主控台顯示執行結果或提示文字
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
