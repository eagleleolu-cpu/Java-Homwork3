public class CH4_P26 { // 宣告本範例的類別，定義物件的資料與行為
    static class Car { } // 完成此處的 Java 程式結構
    static class RacingCar extends Car { } // 運用繼承或介面實作重複使用程式設計
    public static void main(String[] args) { // Java 主程式的執行入口
        Car[] cars = {new Car(), new RacingCar()}; // 使用 new 建立物件並完成初始設定
        for (Car car : cars) { // 使用迴圈反覆處理一組資料
            System.out.println("類別名稱：" + car.getClass().getSimpleName()); // 在主控台顯示執行結果或提示文字
        } // 結束目前的程式區塊
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
