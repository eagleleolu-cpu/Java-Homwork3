public class CH5_P24 { // 宣告本範例的類別，定義物件的資料與行為
    public static void main(String[] args) { // Java 主程式的執行入口
        try { // 嘗試執行可能發生例外的操作
            int[] values = new int[2]; // 使用 new 建立物件並完成初始設定
            System.out.println(values[4]); // 在主控台顯示執行結果或提示文字
        } catch (ArrayIndexOutOfBoundsException e) { // 捕捉指定種類的例外，避免直接中斷
            System.out.println("發生陣列越界"); // 在主控台顯示執行結果或提示文字
        } finally { // 進入例外處理的最後收尾區塊
            System.out.println("finally：完成收尾作業"); // 在主控台顯示執行結果或提示文字
        } // 結束目前的程式區塊
        System.out.println("繼續主程式"); // 在主控台顯示執行結果或提示文字
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
