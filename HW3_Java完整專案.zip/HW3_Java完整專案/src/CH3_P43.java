public class CH3_P43 { // 宣告本範例的類別，定義物件的資料與行為
    public static void main(String[] args) { // Java 主程式的執行入口
        int first = 78; // 設定變數的數值或取得方法的處理結果
        int second = 92; // 設定變數的數值或取得方法的處理結果
        int maxScore = Math.max(first, second); // 設定變數的數值或取得方法的處理結果
        System.out.println("較高分數：" + maxScore); // 在主控台顯示執行結果或提示文字
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
