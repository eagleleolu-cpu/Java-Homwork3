public class CH3_P14 { // 宣告本範例的類別，定義物件的資料與行為
    static class Car { // 開始此方法、控制流程或類別區塊
        private int number; // 宣告成員欄位並設定適當的存取範圍
        private double gas; // 宣告成員欄位並設定適當的存取範圍
        void setNum(int n) { number = n; } // 定義不需要回傳結果的物件方法
        void setGas(double g) { gas = g; } // 定義不需要回傳結果的物件方法
        void show() { System.out.println(number + " / " + gas); } // 定義不需要回傳結果的物件方法
    } // 結束目前的程式區塊
    public static void main(String[] args) { // Java 主程式的執行入口
        Car car = new Car(); // 使用 new 建立物件並完成初始設定
        car.setNum(1234); // 執行此行的指定運算或物件操作
        car.setGas(20.5); // 執行此行的指定運算或物件操作
        car.show(); // 執行此行的指定運算或物件操作
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
