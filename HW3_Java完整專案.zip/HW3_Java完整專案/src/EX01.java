import java.util.ArrayList; // 匯入範例需要的 Java 標準函式庫
import java.util.Collections; // 匯入範例需要的 Java 標準函式庫
import java.util.List; // 匯入範例需要的 Java 標準函式庫
public class EX01 { // 宣告本範例的類別，定義物件的資料與行為
    static class GradeBook { // 開始此方法、控制流程或類別區塊
        private final List<Integer> grades = new ArrayList<>(); // 使用 new 建立物件並完成初始設定
        void addGrade(int score) { // 定義不需要回傳結果的物件方法
            if (score < 0 || score > 100) { throw new IllegalArgumentException("成績需介於 0～100"); } // 依照條件判斷是否執行下面的程式
            grades.add(score); // 執行此行的指定運算或物件操作
        } // 結束目前的程式區塊
        double average() { return grades.stream().mapToInt(Integer::intValue).average().orElse(0.0); } // 定義具有回傳值的物件方法
        int highest() { return Collections.max(grades); } // 定義具有回傳值的物件方法
        long passed() { return grades.stream().filter(value -> value >= 60).count(); } // 完成此處的 Java 程式結構
    } // 結束目前的程式區塊
    public static void main(String[] args) { // Java 主程式的執行入口
        GradeBook book = new GradeBook(); // 使用 new 建立物件並完成初始設定
        book.addGrade(88); book.addGrade(75); book.addGrade(52); // 執行此行的指定運算或物件操作
        System.out.printf("平均：%.1f，最高：%d，及格人數：%d%n", book.average(), book.highest(), book.passed()); // 在主控台顯示執行結果或提示文字
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
