public class CH3_P22 { // 宣告本範例的類別，定義物件的資料與行為
    static class Car { // 開始此方法、控制流程或類別區塊
        private int number; // 宣告成員欄位並設定適當的存取範圍
        private double gas; // 宣告成員欄位並設定適當的存取範圍
        void setCar(int n, double g) { // 定義不需要回傳結果的物件方法
            if (g < 0 || g > 100) { // 依照條件判斷是否執行下面的程式
                System.out.println("油量不合法，保留原有資料"); // 在主控台顯示執行結果或提示文字
                return; // 執行此行的指定運算或物件操作
            } // 結束目前的程式區塊
            number = n; gas = g; // 設定變數的數值或取得方法的處理結果
        } // 結束目前的程式區塊
        void show() { System.out.println("車號 " + number + "，油量 " + gas); } // 定義不需要回傳結果的物件方法
    } // 結束目前的程式區塊
    public static void main(String[] args) { // Java 主程式的執行入口
        Car car = new Car(); // 使用 new 建立物件並完成初始設定
        car.setCar(1234, 20.5); // 執行此行的指定運算或物件操作
        car.setCar(9999, -10.0); // 執行此行的指定運算或物件操作
        car.show(); // 執行此行的指定運算或物件操作
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
