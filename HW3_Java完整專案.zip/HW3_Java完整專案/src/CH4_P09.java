public class CH4_P09 { // 宣告本範例的類別，定義物件的資料與行為
    static class Car { // 開始此方法、控制流程或類別區塊
        protected int number = 1234; // 宣告成員欄位並設定適當的存取範圍
        protected double gas = 20.5; // 宣告成員欄位並設定適當的存取範圍
    } // 結束目前的程式區塊
    static class RacingCar extends Car { // 運用繼承或介面實作重複使用程式設計
        void show() { System.out.println("賽車：" + number + " / " + gas); } // 定義不需要回傳結果的物件方法
    } // 結束目前的程式區塊
    public static void main(String[] args) { new RacingCar().show(); } // Java 主程式的執行入口
} // 結束目前的程式區塊
