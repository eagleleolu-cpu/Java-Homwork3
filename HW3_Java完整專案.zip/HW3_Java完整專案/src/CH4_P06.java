public class CH4_P06 { // 宣告本範例的類別，定義物件的資料與行為
    static class Car { // 開始此方法、控制流程或類別區塊
        private int number; // 宣告成員欄位並設定適當的存取範圍
        private double gas; // 宣告成員欄位並設定適當的存取範圍
        Car(int n, double g) { number = n; gas = g; } // 設定變數的數值或取得方法的處理結果
        void show() { System.out.println(number + " / " + gas); } // 定義不需要回傳結果的物件方法
    } // 結束目前的程式區塊
    static class RacingCar extends Car { // 運用繼承或介面實作重複使用程式設計
        private int course; // 宣告成員欄位並設定適當的存取範圍
        RacingCar(int n, double g, int c) { super(n, g); course = c; } // 設定變數的數值或取得方法的處理結果
        void info() { show(); System.out.println("賽道：" + course); } // 定義不需要回傳結果的物件方法
    } // 結束目前的程式區塊
    public static void main(String[] args) { new RacingCar(1234, 20.5, 5).info(); } // Java 主程式的執行入口
} // 結束目前的程式區塊
