import java.io.BufferedReader; // 匯入範例需要的 Java 標準函式庫
import java.io.StringReader; // 匯入範例需要的 Java 標準函式庫
import java.io.IOException; // 匯入範例需要的 Java 標準函式庫
public class CH3_P34 { // 宣告本範例的類別，定義物件的資料與行為
    public static void main(String[] args) throws IOException { // Java 主程式的執行入口
        BufferedReader reader = new BufferedReader(new StringReader("42")); // 使用 new 建立物件並完成初始設定
        String text = reader.readLine(); // 從文字串流讀取一行資料
        int number = Integer.parseInt(text); // 設定變數的數值或取得方法的處理結果
        System.out.println("輸入數值：" + number); // 在主控台顯示執行結果或提示文字
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
