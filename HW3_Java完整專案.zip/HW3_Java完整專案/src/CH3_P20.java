public class CH3_P20 { // 宣告本範例的類別，定義物件的資料與行為
    static class Car { // 開始此方法、控制流程或類別區塊
        int number; // 執行此行的指定運算或物件操作
        double gas; // 執行此行的指定運算或物件操作
    } // 結束目前的程式區塊
    public static void main(String[] args) { // Java 主程式的執行入口
        Car car = new Car(); // 使用 new 建立物件並完成初始設定
        car.number = 1234; // 設定變數的數值或取得方法的處理結果
        car.gas = -10.0; // 設定變數的數值或取得方法的處理結果
        System.out.println("錯誤油量仍被設入：" + car.gas); // 在主控台顯示執行結果或提示文字
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
