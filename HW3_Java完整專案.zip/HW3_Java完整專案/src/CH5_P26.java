public class CH5_P26 { // 宣告本範例的類別，定義物件的資料與行為
    public static void main(String[] args) { // Java 主程式的執行入口
        try { // 嘗試執行可能發生例外的操作
            int[] values = {1, 2, 3}; // 設定變數的數值或取得方法的處理結果
            System.out.println(values[10]); // 在主控台顯示執行結果或提示文字
        } catch (ArrayIndexOutOfBoundsException e) { // 捕捉指定種類的例外，避免直接中斷
            System.out.println("例外類別：" + e.getClass().getSimpleName()); // 在主控台顯示執行結果或提示文字
            System.out.println("訊息：" + e.getMessage()); // 在主控台顯示執行結果或提示文字
        } // 結束目前的程式區塊
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
