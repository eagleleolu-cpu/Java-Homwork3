public class CH4_P38 { // 宣告本範例的類別，定義物件的資料與行為
    interface Vehicle { void show(); } // 宣告介面或抽象類別，規範子類別必須完成的功能
    static class Car implements Vehicle { // 運用繼承或介面實作重複使用程式設計
        @Override // 標示此方法是覆寫父類別或介面的方法
        public void show() { System.out.println("汽車行駛中"); } // 定義不需要回傳結果的物件方法
    } // 結束目前的程式區塊
    static class Plane implements Vehicle { // 運用繼承或介面實作重複使用程式設計
        @Override // 標示此方法是覆寫父類別或介面的方法
        public void show() { System.out.println("飛機飛行中"); } // 定義不需要回傳結果的物件方法
    } // 結束目前的程式區塊
    public static void main(String[] args) { // Java 主程式的執行入口
        Vehicle[] vehicles = {new Car(), new Plane()}; // 使用 new 建立物件並完成初始設定
        for (Vehicle v : vehicles) { v.show(); } // 使用迴圈反覆處理一組資料
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
