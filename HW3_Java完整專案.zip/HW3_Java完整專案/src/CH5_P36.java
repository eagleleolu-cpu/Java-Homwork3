import java.io.BufferedReader; // 匯入範例需要的 Java 標準函式庫
import java.io.IOException; // 匯入範例需要的 Java 標準函式庫
import java.nio.charset.StandardCharsets; // 匯入範例需要的 Java 標準函式庫
import java.nio.file.Files; // 匯入範例需要的 Java 標準函式庫
import java.nio.file.Path; // 匯入範例需要的 Java 標準函式庫
import java.nio.file.Paths; // 匯入範例需要的 Java 標準函式庫
public class CH5_P36 { // 宣告本範例的類別，定義物件的資料與行為
    public static void main(String[] args) throws IOException { // Java 主程式的執行入口
        Path file = Paths.get("data", "ch5_p35.txt"); // 設定變數的數值或取得方法的處理結果
        if (!Files.exists(file)) { System.out.println("請先執行 CH5_P35 產生檔案"); return; } // 依照條件判斷是否執行下面的程式
        try (BufferedReader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) { // 嘗試執行可能發生例外的操作
            String line; // 執行此行的指定運算或物件操作
            while ((line = reader.readLine()) != null) { System.out.println(line); } // 持續重複執行直到條件不成立
        } // 結束目前的程式區塊
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
