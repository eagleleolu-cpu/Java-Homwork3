public class CH3_P12 { // 宣告本範例的類別，定義物件的資料與行為
    static class Car { // 開始此方法、控制流程或類別區塊
        int number = 1234; // 設定變數的數值或取得方法的處理結果
        void show() { System.out.println("車號：" + number); } // 定義不需要回傳結果的物件方法
        void showDetails() { // 定義不需要回傳結果的物件方法
            System.out.println("開始顯示車輛資料"); // 在主控台顯示執行結果或提示文字
            this.show(); // 執行此行的指定運算或物件操作
        } // 結束目前的程式區塊
    } // 結束目前的程式區塊
    public static void main(String[] args) { new Car().showDetails(); } // Java 主程式的執行入口
} // 結束目前的程式區塊
