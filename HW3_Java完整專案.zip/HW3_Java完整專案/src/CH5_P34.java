import java.io.BufferedReader; // 匯入範例需要的 Java 標準函式庫
import java.io.InputStreamReader; // 匯入範例需要的 Java 標準函式庫
import java.io.IOException; // 匯入範例需要的 Java 標準函式庫
import java.nio.charset.StandardCharsets; // 匯入範例需要的 Java 標準函式庫
public class CH5_P34 { // 宣告本範例的類別，定義物件的資料與行為
    public static void main(String[] args) throws IOException { // Java 主程式的執行入口
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8)); // 使用 new 建立物件並完成初始設定
        System.out.println("請輸入文字："); // 在主控台顯示執行結果或提示文字
        String text = reader.readLine(); // 從文字串流讀取一行資料
        System.out.println("已輸入：" + text); // 在主控台顯示執行結果或提示文字
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
