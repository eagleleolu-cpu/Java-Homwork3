public class CH3_P05 { // 宣告本範例的類別，定義物件的資料與行為
    static class Car { String model = "小客車"; } // 設定變數的數值或取得方法的處理結果
    public static void main(String[] args) { // Java 主程式的執行入口
        Car car1; // 執行此行的指定運算或物件操作
        car1 = new Car(); // 使用 new 建立物件並完成初始設定
        System.out.println("已建立車輛：" + car1.model); // 在主控台顯示執行結果或提示文字
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
