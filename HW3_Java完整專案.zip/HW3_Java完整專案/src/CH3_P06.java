public class CH3_P06 { // 宣告本範例的類別，定義物件的資料與行為
    static class Car { int number; double gas; } // 完成此處的 Java 程式結構
    public static void main(String[] args) { // Java 主程式的執行入口
        Car car = new Car(); // 使用 new 建立物件並完成初始設定
        car.number = 1234; // 設定變數的數值或取得方法的處理結果
        car.gas = 20.5; // 設定變數的數值或取得方法的處理結果
        System.out.println("車號：" + car.number + "，汽油量：" + car.gas); // 在主控台顯示執行結果或提示文字
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
