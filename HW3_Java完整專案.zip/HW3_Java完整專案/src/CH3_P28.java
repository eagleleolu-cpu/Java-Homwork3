public class CH3_P28 { // 宣告本範例的類別，定義物件的資料與行為
    static class Car { // 開始此方法、控制流程或類別區塊
        private int number; // 宣告成員欄位並設定適當的存取範圍
        private double gas; // 宣告成員欄位並設定適當的存取範圍
        Car() { this(0, 0.0); } // 完成此處的 Java 程式結構
        Car(int n, double g) { number = n; gas = g; } // 設定變數的數值或取得方法的處理結果
        void show() { System.out.println("車號 " + number + " / 油量 " + gas); } // 定義不需要回傳結果的物件方法
    } // 結束目前的程式區塊
    public static void main(String[] args) { // Java 主程式的執行入口
        new Car().show(); // 使用 new 建立物件並完成初始設定
        new Car(1234, 20.5).show(); // 使用 new 建立物件並完成初始設定
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
