import java.net.URI; // 匯入範例需要的 Java 標準函式庫
import java.net.URISyntaxException; // 匯入範例需要的 Java 標準函式庫
public class EX03 { // 宣告本範例的類別，定義物件的資料與行為
    public static void main(String[] args) { // Java 主程式的執行入口
        String text = "https://www.ntut.edu.tw/about?lang=zh"; // 設定變數的數值或取得方法的處理結果
        try { // 嘗試執行可能發生例外的操作
            URI uri = new URI(text); // 使用 new 建立物件並完成初始設定
            if (!"https".equalsIgnoreCase(uri.getScheme())) { throw new IllegalArgumentException("只允許 HTTPS"); } // 依照條件判斷是否執行下面的程式
            System.out.println("通訊協定：" + uri.getScheme()); // 在主控台顯示執行結果或提示文字
            System.out.println("主機名稱：" + uri.getHost()); // 在主控台顯示執行結果或提示文字
            System.out.println("路徑：" + uri.getPath()); // 在主控台顯示執行結果或提示文字
            System.out.println("查詢參數：" + uri.getQuery()); // 在主控台顯示執行結果或提示文字
        } catch (URISyntaxException | IllegalArgumentException e) { // 捕捉指定種類的例外，避免直接中斷
            System.out.println("網址格式有誤：" + e.getMessage()); // 在主控台顯示執行結果或提示文字
        } // 結束目前的程式區塊
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
