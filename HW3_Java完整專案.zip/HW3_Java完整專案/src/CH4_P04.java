public class CH4_P04 { // 宣告本範例的類別，定義物件的資料與行為
    static class Car { // 開始此方法、控制流程或類別區塊
        void show() { System.out.println("一般汽車"); } // 定義不需要回傳結果的物件方法
    } // 結束目前的程式區塊
    static class RacingCar extends Car { // 運用繼承或介面實作重複使用程式設計
        void setCourse(int course) { System.out.println("賽車編號：" + course); } // 定義不需要回傳結果的物件方法
    } // 結束目前的程式區塊
    public static void main(String[] args) { // Java 主程式的執行入口
        RacingCar racer = new RacingCar(); // 使用 new 建立物件並完成初始設定
        racer.show(); // 執行此行的指定運算或物件操作
        racer.setCourse(5); // 執行此行的指定運算或物件操作
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
