import java.io.BufferedReader; // 匯入範例需要的 Java 標準函式庫
import java.io.BufferedWriter; // 匯入範例需要的 Java 標準函式庫
import java.io.IOException; // 匯入範例需要的 Java 標準函式庫
import java.nio.charset.StandardCharsets; // 匯入範例需要的 Java 標準函式庫
import java.nio.file.Files; // 匯入範例需要的 Java 標準函式庫
import java.nio.file.Path; // 匯入範例需要的 Java 標準函式庫
import java.nio.file.Paths; // 匯入範例需要的 Java 標準函式庫
public class EX02 { // 宣告本範例的類別，定義物件的資料與行為
    public static void main(String[] args) throws IOException { // Java 主程式的執行入口
        Path folder = Paths.get("data"); // 設定變數的數值或取得方法的處理結果
        Files.createDirectories(folder); // 執行此行的指定運算或物件操作
        Path file = folder.resolve("study_notes.txt"); // 設定變數的數值或取得方法的處理結果
        try (BufferedWriter writer = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) { // 嘗試執行可能發生例外的操作
            writer.write("讀書會重點：封裝、繼承、例外處理"); // 將文字內容寫入輸出串流
            writer.newLine(); // 執行此行的指定運算或物件操作
            writer.write("下次複習：Thread 與 synchronized"); // 限制同時存取共用資料，避免競爭條件
        } // 結束目前的程式區塊
        try (BufferedReader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) { // 嘗試執行可能發生例外的操作
            String line; // 執行此行的指定運算或物件操作
            while ((line = reader.readLine()) != null) { System.out.println(line); } // 持續重複執行直到條件不成立
        } // 結束目前的程式區塊
    } // 結束目前的程式區塊
} // 結束目前的程式區塊
