# 應用軟體實習 Homework HW3 - CH3 / CH4 / CH5

## 組員
- 113340450 盧冠行
- 111362549 謝宗叡

## 依講義整理的題數
- CH3：26 題（P5、P6、P7、P9、P11、P12、P14、P15、P16、P17、P20、P22、P24、P26、P27、P28、P31、P34、P36、P37、P38、P40、P43、P45、P47、P51）
- CH4：13 題（P4、P6、P9、P11、P14、P17、P24、P25、P26、P29、P32、P38、P41）
- CH5：22 題（P6、P8、P10、P14、P19、P21、P24、P26、P30、P32、P34、P35、P36、P40、P44、P45、P46、P47、P48、P50、P52、P55）
- ChatGPT 延伸：3 題（java.util / java.io / java.net）
- 總計：64 個可執行範例；部分跨檔案題有兩個 .java 檔。

## 編譯與執行
本專案提供 Java 21 完整編譯與執行驗證紀錄；程式基本上使用 Java 8 之後的常見語法。建議使用 JDK 17 或更新版本，文字編碼 UTF-8。

### Windows
1. 以檔案總管進入專案根目錄。
2. 安裝 JDK 並確認 `java -version` / `javac -version` 可使用。
3. 執行 `build_and_test.bat`（會先編譯所有 `.java`，再執行批次驗證）。
4. 若只想執行某題：`java -cp build CH3_P05`。
5. CH5 P06、P08、P10、P14 為套件範例，使用完整類別名稱，例如 `java -cp build hw3.ch5.p14.pb.Main`。

### macOS/Linux
`bash build_and_test.sh`

### 手動編譯
將 src 資料夾下所有 `.java` 檔加入同一個 Java 專案後編譯；執行主類別 Main 或 CH3_Pxx 等即可。

## 特殊案例
- `CH5_P19` 是講義要求觀察未處理例外的範例：預期丟出 `ArrayIndexOutOfBoundsException`，因此非零退出狀態屬於**符合設計**。
- `CH5_P35` 先寫入 `data/ch5_p35.txt`；`CH5_P36` 再讀取此檔案。
- `CH5_P34` 需要鍵盤輸入一行文字；自動測試會輸入 `Hello`。
- `CH5_P40` 需帶入資料檔名稱；自動測試使用 `data/ch5_p35.txt`。
- `CH5_P52` 是故意保留競爭條件，輸出可能有差異；`CH5_P55` 用 `synchronized` 修正。
- CH5 講義表格將 `java.lang` 寫成 `java.long`，Java 的正確套件名稱是 `java.lang`。

## 重要：尚未能由程式自動完成的繳交證明
- 讀書會的**實際討論時間、地點、照片或 Meet 紀錄**：需由組員提供。
- **GitHub 儲存庫網址及上傳後的真實頁面截圖**：需由組員上傳後補入報告。
- 個人心得與分工請依組員真實參與情況核對。

## 繳交
- 期限：2026/11/26（星期四）23:59 前。
- 指定檔名：學號_姓名.pdf。
- 上傳位置：Homework\Upload；另須上傳 GitHub。

## 程式碼註解
所有非空白 Java 程式行均有繁體中文行尾註解，便於學生逐行檢查。
