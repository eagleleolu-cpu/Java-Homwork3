#!/usr/bin/env bash
set -euo pipefail
export LANG=C.UTF-8
mkdir -p build
find src -name '*.java' -print0 | xargs -0 javac -encoding UTF-8 -d build
python3 verify_all.py
